<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="cadastroee.model.Produto"%>

<%
    Produto produto =
            (Produto) request.getAttribute("produto");

    String acao;
    String textoBotao;

    if(produto == null){

        acao="incluir";
        textoBotao="Adicionar Produto";

    }else{

        acao="alterar";
        textoBotao="Alterar Produto";

    }

%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Cadastro Produto</title>

<!-- Bootstrap CSS -->

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
      rel="stylesheet">

<!-- Bootstrap JavaScript -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js">
</script>

</head>

<body class="container">

<h1 class="mt-4 mb-4">

Cadastro de Produto

</h1>

<form action="ServletProdutoFC"
      method="post"
      class="form">

<input type="hidden"
       name="acao"
       value="<%=acao%>">

<%

if("alterar".equals(acao)){

%>

<input type="hidden"
       name="id"
       value="<%=produto.getId()%>">

<%

}

%>

<div class="mb-3">

<label class="form-label">

Nome

</label>

<input type="text"
       class="form-control"
       name="nome"
       value="<%=produto!=null?produto.getNome():""%>">

</div>


<div class="mb-3">

<label class="form-label">

Quantidade

</label>

<input type="text"
       class="form-control"
       name="quantidade"
       value="<%=produto!=null?produto.getQuantidade():""%>">

</div>


<div class="mb-3">

<label class="form-label">

Preço de Venda

</label>

<input type="text"
       class="form-control"
       name="precoVenda"
       value="<%=produto!=null?produto.getPrecoVenda():""%>">

</div>


<input type="submit"
       class="btn btn-primary"
       value="<%=textoBotao%>">

<a href="ServletProdutoFC?acao=listar"
   class="btn btn-secondary">

Voltar

</a>

</form>

</body>

</html>