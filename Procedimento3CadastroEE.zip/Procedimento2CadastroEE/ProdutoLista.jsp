<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="cadastroee.model.Produto"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Lista de Produtos</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
      rel="stylesheet">

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js">
</script>

</head>

<body class="container">

    <h1>Lista de Produtos</h1>

    <a href="ServletProdutoFC?acao=formIncluir"
       class="btn btn-primary m-2">

        Incluir Produto

    </a>

    <table class="table table-striped">

        <thead class="table-dark">

            <tr>

                <th>ID</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Preço Venda</th>
                <th>Alterar</th>
                <th>Excluir</th>

            </tr>

        </thead>

        <tbody>

        <%

            List<Produto> produtos =
            (List<Produto>) request.getAttribute("produtos");

            if(produtos != null){

                for(Produto produto : produtos){

        %>

        <tr>

            <td><%=produto.getId()%></td>

            <td><%=produto.getNome()%></td>

            <td><%=produto.getQuantidade()%></td>

            <td>
                R$ <%=String.format("%.2f",
                        produto.getPrecoVenda())%>
            </td>

            <td>

                <a href="ServletProdutoFC?acao=formAlterar&id=<%=produto.getId()%>"
                   class="btn btn-primary btn-sm">

                    Alterar

                </a>

            </td>

            <td>

                <a href="ServletProdutoFC?acao=excluir&id=<%=produto.getId()%>"
                   class="btn btn-danger btn-sm">

                    Excluir

                </a>

            </td>

        </tr>

        <%

                }
            }

        %>

        </tbody>

    </table>

</body>

</html>