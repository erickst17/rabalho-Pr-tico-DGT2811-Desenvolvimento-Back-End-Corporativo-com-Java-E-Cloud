/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package cadastroee.servlets;

import cadastroee.controller.ProdutoFacadeLocal;
import cadastroee.model.Produto;
import java.io.IOException;
import java.util.List;
import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ServletProdutoFC extends HttpServlet {

    @EJB
    private ProdutoFacadeLocal facade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String acao = request.getParameter("acao");

        if (acao == null) {
            acao = "listar";
        }

        String destino;

        if (acao.equals("formIncluir") || acao.equals("formAlterar")) {
            destino = "ProdutoDados.jsp";
        } else {
            destino = "ProdutoLista.jsp";
        }

        if (acao.equals("listar")) {

            List<Produto> produtos = facade.findAll();
            request.setAttribute("produtos", produtos);

        } else if (acao.equals("formAlterar")) {

            Integer id = Integer.valueOf(request.getParameter("id"));
            Produto produto = facade.find(id);
            request.setAttribute("produto", produto);

        } else if (acao.equals("excluir")) {

            Integer id = Integer.valueOf(request.getParameter("id"));
            Produto produto = facade.find(id);

            if (produto != null) {
                facade.remove(produto);
            }

            List<Produto> produtos = facade.findAll();
            request.setAttribute("produtos", produtos);

        } else if (acao.equals("alterar")) {

            Integer id = Integer.valueOf(request.getParameter("id"));
            Produto produto = facade.find(id);

            produto.setNome(request.getParameter("nome"));
            produto.setQuantidade(Double.parseDouble(request.getParameter("quantidade")));
            produto.setPrecoVenda(Double.parseDouble(request.getParameter("precoVenda")));

            facade.edit(produto);

            List<Produto> produtos = facade.findAll();
            request.setAttribute("produtos", produtos);

        } else if (acao.equals("incluir")) {

            Produto produto = new Produto();

            produto.setNome(request.getParameter("nome"));
            produto.setQuantidade(Double.parseDouble(request.getParameter("quantidade")));
            produto.setPrecoVenda(Double.parseDouble(request.getParameter("precoVenda")));

            facade.create(produto);

            List<Produto> produtos = facade.findAll();
            request.setAttribute("produtos", produtos);
        }

        RequestDispatcher rd = request.getRequestDispatcher(destino);
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}