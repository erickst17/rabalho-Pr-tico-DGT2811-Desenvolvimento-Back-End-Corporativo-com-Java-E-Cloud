<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="cadastroee.model.Produto"%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lista de Produtos</title>
    </head>

    <body>

        <h1>Lista de Produtos</h1>

        <p>
            <a href="ServletProdutoFC?acao=formIncluir">
                Incluir Novo Produto
            </a>
        </p>

        <table border="1">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Preço de Venda</th>
                <th>Alterar</th>
                <th>Excluir</th>
            </tr>

            <%
                List<Produto> produtos = 
                    (List<Produto>) request.getAttribute("produtos");

                if (produtos != null) {
                    for (Produto produto : produtos) {
            %>

            <tr>
                <td><%= produto.getId() %></td>
                <td><%= produto.getNome() %></td>
                <td><%= produto.getQuantidade() %></td>
                <td><%= produto.getPrecoVenda() %></td>

                <td>
                    <a href="ServletProdutoFC?acao=formAlterar&id=<%= produto.getId() %>">
                        Alterar
                    </a>
                </td>

                <td>
                    <a href="ServletProdutoFC?acao=excluir&id=<%= produto.getId() %>">
                        Excluir
                    </a>
                </td>
            </tr>

            <%
                    }
                }
            %>

        </table>

    </body>
</html>