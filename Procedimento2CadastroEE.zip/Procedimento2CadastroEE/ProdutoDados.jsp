<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="cadastroee.model.Produto"%>

<%
    Produto produto = (Produto) request.getAttribute("produto");

    String acao;
    String textoBotao;

    if (produto == null) {
        acao = "incluir";
        textoBotao = "Adicionar Produto";
    } else {
        acao = "alterar";
        textoBotao = "Alterar Produto";
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Dados do Produto</title>
    </head>

    <body>

        <h1>Dados do Produto</h1>

        <form action="ServletProdutoFC" method="post">

            <input type="hidden" name="acao" value="<%= acao %>">

            <% if ("alterar".equals(acao)) { %>
                <input type="hidden" name="id" value="<%= produto.getId() %>">
            <% } %>

            Nome:
            <input type="text" name="nome"
                   value="<%= produto != null ? produto.getNome() : "" %>">

            Quantidade:
            <input type="text" name="quantidade"
                   value="<%= produto != null ? produto.getQuantidade() : "" %>">

            Preço de Venda:
            <input type="text" name="precoVenda"
                   value="<%= produto != null ? produto.getPrecoVenda() : "" %>">

            <br>

            <input type="submit" value="<%= textoBotao %>">

        </form>

    </body>
</html>